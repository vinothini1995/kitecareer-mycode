import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

import Header from '../components/Header';
import styled, { keyframes } from 'styled-components';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faRobot, faMicrochip, faLock, faBlockchain, faCogs } from '@fortawesome/free-solid-svg-icons';
import aboutimage from '../images/homepage img.jpg';
import { Button } from '@mui/material';
import image1 from '../images/homepage img.jpg';
import CarouselComp from '../components/CarouselComp';
import OurClients from './OurClients';
import LeadershipTeam from '../components/LeadershipTeam';
import backgroundImage from '../images/digitalizationbg.jpg';
import ProjectsSection from './ProjectsSection ';

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`;


const AboutContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: #f5f5f5;
  overflow-x: hidden; /* Prevent horizontal scroll */
  padding-bottom:40px;
`;

const Section = styled.div`
  width: 100%;
  max-width: 1200px; /* Control the maximum width */
  background: ${(props) => props.bgColor || 'linear-gradient(to right, #295F98, #ffffff)'}; /* Linear gradient fallback */
  padding: 40px;
  margin-bottom: 20px;
  height:300px;
  color: black;
  border-radius: 10px;
  animation: ${fadeIn} 1s ease-in-out; /* Add fade-in animation */
  transition: transform 0.3s ease; /* Smooth hover effect */

  &:hover {
    transform: scale(1.05); /* Slightly enlarge on hover */
  }
`;

const TextContainer = styled.div`
  padding: 20px;
  color: white;
  width: 500px;
`;

const SectionContent = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between; /* Aligns image and text side by side */
  background-image: url(${backgroundImage}); /* Using the imported image */
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  padding: 40px;
  width: 100%;
`;

const IconButton = styled(Button)`
`;
const About = () => {
  const [textColor, setTextColor] = useState('white');

  // Array of colors that change in sync with background gradient
  const colorPhases = ['#ffffff', '#ffdd57', '#00ff99', '#ff5733'];

  useEffect(() => {
    let phaseIndex = 0;

    // Change text color every 2.5 seconds (since animation duration is 10s)
    const colorInterval = setInterval(() => {
      setTextColor(colorPhases[phaseIndex]);
      phaseIndex = (phaseIndex + 1) % colorPhases.length;
    }, 2500); // Match interval to gradient phase (10s total / 4 phases)

    return () => clearInterval(colorInterval);
  }, []);
  return (
    <AboutContainer>
      <Header />
      
      {/* Section 1 */}
      {/* <Section bgColor="linear-gradient(to right, #295F98, #ffffff)" style={{textAlign:'justify'}}>
        <h1>"WHERE EMPLOYEE PASSION MEETS EXCEPTIONAL CUSTOMER OUTCOMES."</h1>
        <p>
        At our company, the passion and expertise of our employees are the driving forces behind the exceptional outcomes we deliver to our clients. We believe that when a team is truly invested in their work, it reflects in every solution we provide. Our collaborative culture fosters innovation, creativity, and continuous learning, ensuring that we stay ahead of industry trends. This dedication allows us to not only meet but exceed client expectations, creating solutions that are both impactful and future-ready. By aligning our passion with customer goals, we deliver transformative results that fuel long-term success.</p>
      </Section> */}

      {/* Section 2 */}
      <SectionContent>
        <div style={{width:'700px',height:'300px',margin:'10px',borderRadius:'10px',textAlign:'justify',color:'white',border:'2px dashed white',padding:'10px'}}>
        <h1>Who We Are</h1>
        <p>We are a team of passionate developers, designers, and innovators, dedicated to crafting intelligent, cutting-edge software solutions that empower businesses to reach new heights. Since our inception, we have partnered with organizations worldwide, helping them achieve operational excellence through technology-driven transformation.

</p>

        </div>
        {/* <img src={aboutimage} alt="" style={{ width: '50%', height: 'auto' }} /> */}
        <TextContainer>
          <h1>Six Years Of Top Experiences</h1>
<ul style={{textAlign:'justify',margin:'10px',lineHeight:'30px',listStyle:'inside',}}>
<li>KiteCareer, a 6-year startup in IT solutions and services, offers a range of services including Professional Services, Managed Services, and Business Process Outsourcing.</li>
<li>                      Our team of professionals across software development platforms and the service industry is committed to being the best in reliability, quality, and support.
</li>
         <li>            The team of 50 members specialized in advanced technologies like AI, IoT, Cloud and various development roles across Python, Mobile Apps, Java, UI/UX, and Web Development.
         </li>
</ul>
<Link to="/contact" style={{ textDecoration: 'none' }}>

          <IconButton variant="contained">CALL US NOW</IconButton>
          </Link>
        </TextContainer>
      </SectionContent>
      
      <ProjectsSection/>
      <LeadershipTeam/>
      <OurClients/>
    </AboutContainer>
  );
};

export default About;
