// Import dependencies
import React, { useEffect } from 'react';
import styled from 'styled-components';
import AOS from 'aos';
import 'aos/dist/aos.css'; // Import AOS CSS
import Header from '../components/Header';
import python from '../images/Tech/python.png';
import java from '../images/Tech/java.png';
import php from '../images/Tech/php.png';
import js from '../images/Tech/javascript.png';
import sql from '../images/Tech/sql.png';
import mongodb from '../images/Tech/mongo-db.png';
import mysql from '../images/Tech/mysql.png';
import oracle from '../images/Tech/oracle.png';
import html from '../images/Tech/html.png';
import boot from '../images/Tech/Boot.png';
import css from '../images/Tech/css.png';
import photoshop from '../images/Tech/adobe-photoshop.png';
import figma from '../images/Tech/figma.png';
import reactnative from '../images/Tech/reactnative.png';
import android from '../images/Tech/android.png';
import flutter from '../images/Tech/flutter.png';
import Django from '../images/Tech/django.png'; 
import FastAPI from '../images/Tech/api.png';
import SpringBoot from '../images/Tech/springboot.png';
import Laravel from '../images/Tech/laravel.png';
// Main container styled component
const TechnologyContainer = styled.div`
  padding: 40px;
  background-color: #f4f4f4;
  font-family: Arial, sans-serif;
  min-height: 100vh;
  background: linear-gradient(to bottom, #e0eafc, #cfdef3);
  overflow-x: hidden;
  cursor: pointer;
`;

const Heading = styled.h1`
  text-align: center;
  font-size: 2.5rem;
  color: black;
  margin-bottom: 40px;
`;

// Grid for sections
const SectionGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 20px;
  width: 100%;
  margin-top: 40px;
`;

// Section styled component
const Section = styled.div`
  text-align: center;
  padding: 20px;
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  box-sizing: border-box;
`;

// Icon and title styles
const SectionTitle = styled.h2`
  font-size: 1.8rem;
  color: black;
  margin-bottom: 20px;
  text-decoration: underline;
`;

// Image grid for technologies
const ImageGrid = styled.div`
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  gap: 10px;
`;

const TechImageWrapper = styled.div`
  text-align: center;
`;

const TechImage = styled.img`
  width: 50px;
  height: 50px;
`;

const ImageHeading = styled.h3`
  font-size: 1.2rem;
  color: black;
  margin-top: 10px;
`;

const Technology = () => {
  useEffect(() => {
    AOS.init({ duration: 1000 }); // Initialize AOS with animation duration
  }, []);

  return (
    <div>
      <Header />
      <TechnologyContainer>
        <Heading data-aos="fade-down">Technology We Use</Heading>
<h3 style={{textAlign:'justify'}}>Technology is the use of knowledge to achieve attainable goals in a repeatable manner. In addition, the term "technology" can be used to describe the products of such efforts, including both tangible objects like equipment or kitchenware and intangible ones like computer software.</h3>
        <SectionGrid>
          {/* Programming Section */}
          <Section data-aos="fade-up">
            <SectionTitle>Programming</SectionTitle>
            <ImageGrid>
              <TechImageWrapper>
                <TechImage src={python} alt="Python" />
                <ImageHeading>Python</ImageHeading>
              </TechImageWrapper>

              <TechImageWrapper>
                <TechImage src={java} alt="Java" />
                <ImageHeading>Java</ImageHeading>
              </TechImageWrapper>

              <TechImageWrapper>
                <TechImage src={php} alt="PHP" />
                <ImageHeading>PHP</ImageHeading>
              </TechImageWrapper>

              <TechImageWrapper>
                <TechImage src={js} alt="JavaScript" />
                <ImageHeading>JavaScript</ImageHeading>
              </TechImageWrapper>
            </ImageGrid>
          </Section>

          {/* DB Section */}
          <Section data-aos="zoom-in">
            <SectionTitle>Data Bases</SectionTitle>
            <ImageGrid>
              <TechImageWrapper>
                <TechImage src={sql} alt="SQL" />
                <ImageHeading>SQL</ImageHeading>
              </TechImageWrapper>

              <TechImageWrapper>
                <TechImage src={mysql} alt="MySQL" />
                <ImageHeading>MySQL</ImageHeading>
              </TechImageWrapper>

              <TechImageWrapper>
                <TechImage src={mongodb} alt="MongoDB" />
                <ImageHeading>MongoDB</ImageHeading>
              </TechImageWrapper>

              <TechImageWrapper>
                <TechImage src={oracle} alt="Oracle" />
                <ImageHeading>Oracle</ImageHeading>
              </TechImageWrapper>
            </ImageGrid>
          </Section>

          {/* UI Section */}
          <Section data-aos="flip-right">
            <SectionTitle>UI/UX Design</SectionTitle>
            <ImageGrid>
              <TechImageWrapper>
                <TechImage src={html} alt="HTML" />
                <ImageHeading>HTML</ImageHeading>
              </TechImageWrapper>

              <TechImageWrapper>
                <TechImage src={css} alt="CSS" />
                <ImageHeading>CSS</ImageHeading>
              </TechImageWrapper>

              <TechImageWrapper>
                <TechImage src={boot} alt="Bootstrap" />
                <ImageHeading>Bootstrap</ImageHeading>
              </TechImageWrapper>

              <TechImageWrapper>
                <TechImage src={photoshop} alt="Photoshop" />
                <ImageHeading>Photoshop</ImageHeading>
              </TechImageWrapper>

              <TechImageWrapper>
                <TechImage src={figma} alt="Figma" />
                <ImageHeading>Figma</ImageHeading>
              </TechImageWrapper>
            </ImageGrid>
          </Section>

          {/* Mobile App Section */}
          <Section data-aos="fade-left">
            <SectionTitle>Mobile App</SectionTitle>
            <ImageGrid>
              <TechImageWrapper>
                <TechImage src={reactnative} alt="React Native" />
                <ImageHeading>React Native</ImageHeading>
              </TechImageWrapper>

              <TechImageWrapper>
                <TechImage src={android} alt="Android" />
                <ImageHeading>Android</ImageHeading>
              </TechImageWrapper>

              <TechImageWrapper>
                <TechImage src={flutter} alt="Flutter" />
                <ImageHeading>Flutter</ImageHeading>
              </TechImageWrapper>
            </ImageGrid>
          </Section>

          {/* Frameworks Section */}
          <Section data-aos="flip-up">
            <SectionTitle>Frameworks</SectionTitle>
            <ImageGrid>
              <TechImageWrapper>
                <TechImage src={Django} alt="Django" />
                <ImageHeading>Django</ImageHeading>
              </TechImageWrapper>

              <TechImageWrapper>
                <TechImage src={FastAPI} alt="FastAPI" />
                <ImageHeading>FastAPI</ImageHeading>
              </TechImageWrapper>

              <TechImageWrapper>
                <TechImage src={SpringBoot} alt="SpringBoot" />
                <ImageHeading>SpringBoot</ImageHeading>
              </TechImageWrapper>

              <TechImageWrapper>
                <TechImage src={Laravel} alt="Laravel" />
                <ImageHeading>Laravel</ImageHeading>
              </TechImageWrapper>
            </ImageGrid>
          </Section>
        </SectionGrid>
      </TechnologyContainer>
    </div>
  );
};

export default Technology;
