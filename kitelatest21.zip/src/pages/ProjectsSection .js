import React from 'react';
import styled, { keyframes } from 'styled-components';
import { FontAwesomeIcon as Icon } from '@fortawesome/react-fontawesome';
import { faRobot, faMicrochip, faLock } from '@fortawesome/free-solid-svg-icons';
import background from '../images/digitalizationbg.jpg';

// Keyframe for floating animation of cards
const floatAnimation = keyframes`
  0% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
  100% { transform: translateY(0); }
`;

// Keyframe for icon pulse animation
const pulseAnimation = keyframes`
  0% { transform: scale(1); }
  50% { transform: scale(1.2); }
  100% { transform: scale(1); }
`;

// Styled container for the whole section
const ProjectContainer = styled.div`
  position: relative;
  background-image: url(${background});
  background-size: cover;
  background-attachment: fixed;
  background-position: center;
  padding: 100px 0;
  width: 100vw;
`;

// Styled content to hold the text and icons
const ProjectContent = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr); // Creates 3 columns
  gap: 20px;
  max-width: 1200px;
  margin: 0 auto;
  justify-items: center;
  align-items: center;
`;

// Rounded divs for each project detail with animation
const ProjectParagraph = styled.div`
  background-color: rgba(255, 255, 255, 0.9);
  border-radius: 20px;
  padding: 20px;
  text-align: center;
  width: 350px;
  box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
  animation: ${floatAnimation} 4s ease-in-out infinite;
  
  &:hover {
    box-shadow: 0px 6px 20px rgba(0, 0, 0, 0.2);
  }
`;

// Icon styles with animation
const AnimatedIcon = styled(Icon)`
  color: #007bff;
  font-size: 3rem;
  margin-bottom: 20px;
  animation: ${pulseAnimation} 1s infinite;
`;

// Text and heading styling
const ProjectHeading = styled.h2`
  color: ${({ textColor }) => textColor || '#000'};
  font-size: 2.5rem;
  text-align: center;
  margin-bottom: 50px;
`;

const Text = styled.p`
  color: ${({ textColor }) => textColor || '#333'};
  font-size: 1rem;
  margin-top: 20px;
  line-height: 1.5;
`;
const Heading=styled.div`

`;
// Your React component
const ProjectsSection = ({ textColor }) => {
  return (
    <ProjectContainer>
      <ProjectHeading textColor={textColor} style={{color:'white'}}>We Provide A Wide Range Of Creative Services</ProjectHeading>

      <ProjectContent>
        <ProjectParagraph>
          <AnimatedIcon icon={faRobot} /><Heading><h1>AI</h1></Heading>
          <Text textColor={textColor} style={{textAlign:'justify'}}>
            We lead in AI, using machine learning, NLP, and predictive analytics to drive business success.
            Recent collaborations have delivered advanced, tailored AI solutions for our clients.
          </Text>
        </ProjectParagraph>

        <ProjectParagraph>
          <AnimatedIcon icon={faMicrochip} /><Heading><h1>Internet Of Things</h1></Heading>
          <Text textColor={textColor} style={{textAlign:'justify'}}>
            Our IoT projects integrate smart devices and sensors to build seamless, interconnected systems.
            We enhance efficiency, data collection, and real-time decision-making with our solutions.
          </Text>
        </ProjectParagraph>

        <ProjectParagraph>
          <AnimatedIcon icon={faLock} /><Heading><h1>Blockchain</h1></Heading>
          <Text textColor={textColor} style={{textAlign:'justify'}}>
            We leverage blockchain to develop secure, transparent, and decentralized applications.
            Our projects aim to revolutionize industries by enhancing data integrity and trust.
          </Text>
        </ProjectParagraph>
        <ProjectParagraph>
          <AnimatedIcon icon={faLock} /><Heading><h1>ML</h1></Heading>
          <Text textColor={textColor} style={{textAlign:'justify'}}>
            We leverage blockchain to develop secure, transparent, and decentralized applications.
            Our projects aim to revolutionize industries by enhancing data integrity and trust.
          </Text>
        </ProjectParagraph>

        <ProjectParagraph>
          <AnimatedIcon icon={faLock} /><Heading><h1>SalesForce</h1></Heading>
          <Text textColor={textColor} style={{textAlign:'justify'}}>
            We leverage blockchain to develop secure, transparent, and decentralized applications.
            Our projects aim to revolutionize industries by enhancing data integrity and trust.
          </Text>
        </ProjectParagraph>
        
      </ProjectContent>
    </ProjectContainer>
  );
};

export default ProjectsSection;
