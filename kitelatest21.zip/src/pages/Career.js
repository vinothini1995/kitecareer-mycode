import React, { useState } from 'react';
import styled from 'styled-components';
import Swal from 'sweetalert2';
import { Button, TextField, Grid, FormControl, FormLabel, RadioGroup, FormControlLabel, Radio, Dialog, DialogActions, DialogContent, DialogTitle } from '@mui/material';
import Header from '../components/Header';
import emailjs from 'emailjs-com';

const SERVICE_ID = "service_maqggai";
const TEMPLATE_ID = "template_3lh9n5j";
const USER_ID = "Y8DQKzjEUYuG05aCv";

const PageContainer = styled.div`
  width: 100%;
  box-sizing: border-box;
  background: linear-gradient(to right, #295F98, #ffffff);
`;

const HeroSection = styled.section`
  background: linear-gradient(to right, #295F98, #ffffff);
  color: white;
  padding: 60px 20px;
  text-align: center;
`;

const HeroHeading = styled.h1`
  font-size: 36px;
  margin-bottom: 20px;
`;

const HeroSubheading = styled.h2`
  font-size: 24px;
  margin-bottom: 30px;
`;

const JobListingsSection = styled.section`
  padding: 40px 20px;
  background: #fff;
  margin-top: 20px;
  gap:40px;
`;

const JobCard = styled.div`
  background: white;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  margin: 10px 0;
  padding: 20px;
  display: flex;
  flex-direction: column;
  transition: transform 0.3s ease;

  &:hover {
    transform: translateY(-10px);
  }
`;

const JobTitle = styled.h3`
  margin: 0;
  font-size: 24px;
`;

const JobDetails = styled.p`
  margin: 10px 0;
`;

const StyledTextField = styled(TextField)`
  width: 100%;
  margin-bottom: 20px;
`;

const SubmitButton = styled(Button)`
  margin-top: 20px;
`;

const Career = () => {
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    experience: 'fresher',
    yearsOfExperience: '',
    qualification: '',
    resume: null
  });

  const [errors, setErrors] = useState({});
  const [open, setOpen] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setFormData((prev) => ({ ...prev, resume: file }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name) newErrors.name = 'Name is required';
    if (!formData.email) newErrors.email = 'Email is required';
    if (!formData.phone) newErrors.phone = 'Phone number is required';
    if (formData.experience === 'experienced' && !formData.yearsOfExperience) {
      newErrors.yearsOfExperience = 'Years of experience is required for experienced candidates';
    }
    if (!formData.qualification) newErrors.qualification = 'Qualification is required';
    if (!formData.resume) newErrors.resume = 'Resume file is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validateForm()) {
      Swal.fire({
        icon: 'error',
        title: 'Form Validation Error',
        text: 'Please fill all required fields correctly.'
      });
      return;
    }

    const { name, email, phone, experience, yearsOfExperience, qualification, resume } = formData;
    const formDataToSend = new FormData();
    formDataToSend.append('name', name);
    formDataToSend.append('email', email);
    formDataToSend.append('phone', phone);
    formDataToSend.append('experience', experience);
    formDataToSend.append('yearsOfExperience', yearsOfExperience);
    formDataToSend.append('qualification', qualification);
    if (resume) {
      formDataToSend.append('resume', resume);
  }
    emailjs.send(SERVICE_ID, TEMPLATE_ID, formDataToSend, USER_ID)
      .then((response) => {
        console.log('Email sent successfully:', response);
        Swal.fire({
          icon: 'success',
          title: 'Message Sent Successfully'
        });
        resetForm();
        handleClose();
      })
      .catch((error) => {
        console.error('Error sending email:', error);
        Swal.fire({
          icon: 'error',
          title: 'Failed to Send Message',
          text: `Error: ${error.text || 'An unknown error occurred'}`
        });
      });
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      experience: 'fresher',
      yearsOfExperience: '',
      qualification: '',
      resume: null
    });
    setErrors({});
  };

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    resetForm(); // Reset form when dialog is closed
  };

  return (
    <PageContainer>
      <Header />
      <HeroSection>
        <HeroHeading>Join Our Team</HeroHeading>
        <HeroSubheading>We're looking for talented individuals to join us in creating innovative solutions.</HeroSubheading>
        <Button variant="contained" color="primary" onClick={handleClickOpen}>Explore Opportunities</Button>
      </HeroSection>

      <JobListingsSection>
        <h2>Current Openings</h2>
        {['Senior Computer Programmer', 'UX Designer', 'Product Manager', 'Network Engineer', 'Front-end Developer', 'Full Stack Developer', 'Senior System Engineer', 'Mobile Developer'].map((title, index) => (
          <JobCard key={index}>
            <JobTitle>{title}</JobTitle>
            <JobDetails>Location: KiteCareer, Surandai</JobDetails>
            <JobDetails>Type: Full-Time</JobDetails>
            <div style={{ display: 'flex', justifyContent: 'center' }}>

            <Button variant="contained" color="primary" onClick={handleClickOpen}   sx={{ width:'200px',textAlign:'center',justifyContent:'center',alignItems:'center' }}
            >Apply Now</Button>
            </div>
          </JobCard>
        ))}
      </JobListingsSection>

      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="sm">
        <DialogTitle>Apply Now</DialogTitle>
        <DialogContent>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <StyledTextField
                  label="Full Name"
                  name="name"
                  variant="outlined"
                  value={formData.name}
                  onChange={handleInputChange}
                  error={!!errors.name}
                  helperText={errors.name}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <StyledTextField
                  label="Email"
                  name="email"
                  variant="outlined"
                  value={formData.email}
                  onChange={handleInputChange}
                  error={!!errors.email}
                  helperText={errors.email}
                />
              </Grid>
              <Grid item xs={12}>
                <StyledTextField
                  label="Phone Number"
                  name="phone"
                  variant="outlined"
                  value={formData.phone}
                  onChange={handleInputChange}
                  error={!!errors.phone}
                  helperText={errors.phone}
                />
              </Grid>
              <Grid item xs={12}>
                <FormControl component="fieldset">
                  <FormLabel component="legend">Experience</FormLabel>
                  <RadioGroup
                    aria-label="experience"
                    name="experience"
                    value={formData.experience}
                    onChange={handleInputChange}
                  >
                    <FormControlLabel value="fresher" control={<Radio />} label="Fresher" />
                    <FormControlLabel value="experienced" control={<Radio />} label="Experienced" />
                  </RadioGroup>
                </FormControl>
              </Grid>
              {formData.experience === 'experienced' && (
                <Grid item xs={12}>
                  <StyledTextField
                    label="Years of Experience"
                    name="yearsOfExperience"
                    variant="outlined"
                    value={formData.yearsOfExperience}
                    onChange={handleInputChange}
                    error={!!errors.yearsOfExperience}
                    helperText={errors.yearsOfExperience}
                  />
                </Grid>
              )}
              <Grid item xs={12}>
                <StyledTextField
                  label="Qualification"
                  name="qualification"
                  variant="outlined"
                  value={formData.qualification}
                  onChange={handleInputChange}
                  error={!!errors.qualification}
                  helperText={errors.qualification}
                />
              </Grid>
              <Grid item xs={12}>
                <input
                  type="file"
                  accept=".pdf, .doc, .docx"
                  onChange={handleFileChange}
                  required
                />
                {errors.resume && <p style={{ color: 'red' }}>{errors.resume}</p>}
              </Grid>
            </Grid>
            <SubmitButton variant="contained" color="primary" type="submit">Submit Application</SubmitButton>
          </form>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">Cancel</Button>
        </DialogActions>
      </Dialog>
    </PageContainer>
  );
};

export default Career;
